//
//  mapViewController.swift
//  mapViewController
//
//  Created by CTechMBP20E on 8/3/21.
//

import UIKit

class mapViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func aquaticButtonTapped(_ sender: Any) {
    }
    @IBAction func mammalsButtonTapped(_ sender: Any) {
    }
    @IBAction func reptilesButtonTapped(_ sender: Any) {
    }
    @IBAction func insectsButtonTapped(_ sender: Any) {
    }
    @IBAction func extinctButtonTapped(_ sender: Any) {
    }
    @IBAction func birdsButtonTapped(_ sender: Any) {
    }
    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
