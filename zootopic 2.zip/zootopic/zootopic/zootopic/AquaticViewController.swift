//
//  AquaticViewController.swift
//  AquaticViewController
//
//  Created by CTechMBP20E on 8/3/21.
//

import UIKit

class AquaticViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func seahorseButtonTapped(_ sender: Any) {
    }
    @IBAction func squidButtonTapped(_ sender: Any) {
    }
    @IBAction func sharkButtonTapped(_ sender: Any) {
    }
    @IBAction func jellyfishButtonTapped(_ sender: Any) {
    }
    @IBAction func crabButtonTapped(_ sender: Any) {
    }
    @IBAction func turtleButtonTapped(_ sender: Any) {
    }
    @IBAction func doplhinButtonTapped(_ sender: Any) {
    }
    @IBAction func whaleButtonTapped(_ sender: Any) {
    }
    @IBAction func fishButtonTapped(_ sender: Any) {
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
